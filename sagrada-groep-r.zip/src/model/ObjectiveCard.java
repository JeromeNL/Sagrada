package model;

public class ObjectiveCard {

}
