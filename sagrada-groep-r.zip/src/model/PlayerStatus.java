package model;

public enum PlayerStatus {
	ACCEPTED,
	CHALLENGEE,
	CHALLENGER,
	FINISHED,
	REFUSED
}
